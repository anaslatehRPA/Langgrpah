# Budget Control — Project Alpha

| Item                | Budget (THB) | Actual (THB) | Variance |
|---------------------|--------------|--------------|----------|
| Earthwork           | 500,000      | 480,000      | -20,000  |
| Concrete            | 1,200,000    | 1,210,000    | +10,000  |
| Steel               | 800,000      | 790,000      | -10,000  |
| Labor               | 900,000      | 880,000      | -20,000  |

Notes: Preliminary sample for RAG testing.
