# Schedule — Project Beta

- W01–W02: Site survey & mobilization
- W03–W06: Foundation
- W07–W10: Structure
- W11–W12: Finishing
